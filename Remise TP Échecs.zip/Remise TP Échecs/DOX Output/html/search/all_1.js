var searchData=
[
  ['bishop_4',['Bishop',['../class_chess_game_1_1_bishop.html',1,'ChessGame.Bishop'],['../class_chess_game_1_1_bishop.html#a29a3f672d02412a856a3886828839e38',1,'ChessGame.Bishop.Bishop()']]],
  ['board_5',['Board',['../class_chess_game_1_1_board.html',1,'ChessGame.Board'],['../class_chess_game_1_1_board.html#a25478b9145573697b7d739bcfc4a1f08',1,'ChessGame.Board.Board(int p_width)'],['../class_chess_game_1_1_board.html#a5d80570d725f97d1a6dc79dc134d15ac',1,'ChessGame.Board.Board(string p_serializedBoard)']]]
];
