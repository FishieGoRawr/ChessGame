var searchData=
[
  ['playerlist_201',['PlayerList',['../class_chess_game_1_1_chess_game.html#a52934c9f0af4b20e8a031e80e456f669',1,'ChessGame::ChessGame']]]
];
