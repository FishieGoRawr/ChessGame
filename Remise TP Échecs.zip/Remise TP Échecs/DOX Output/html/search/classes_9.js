var searchData=
[
  ['settings_113',['Settings',['../class_chess_game_1_1_properties_1_1_settings.html',1,'ChessGame::Properties']]]
];
