var searchData=
[
  ['queen_110',['Queen',['../class_chess_game_1_1_queen.html',1,'ChessGame']]]
];
