var searchData=
[
  ['saveplayerlist_161',['savePlayerList',['../class_chess_game_1_1_chess_game.html#aed02e330cc523c8d736c66b4cc2c4614',1,'ChessGame.ChessGame.savePlayerList()'],['../class_chess_game_1_1_game.html#aa7bbf0eaef10167c66ddff6ddaee4aca',1,'ChessGame.Game.savePlayerList()']]],
  ['serializeplayerlist_162',['serializePlayerList',['../class_chess_game_1_1_chess_game.html#ac22b600f609226a6cc535d0db8f9825c',1,'ChessGame.ChessGame.serializePlayerList()'],['../class_chess_game_1_1_game.html#ad73ea078cbc2cbe4ea687b391f07d20d',1,'ChessGame.Game.serializePlayerList()']]],
  ['switchturns_163',['switchTurns',['../class_chess_game_1_1_game.html#a2a841fb7c547ac684e1e8dbfd8be348e',1,'ChessGame::Game']]]
];
