var searchData=
[
  ['components_167',['components',['../class_chess_game_1_1game_g_u_i.html#aaf71f84feddcac8a9212969307054fdd',1,'ChessGame.gameGUI::components()'],['../class_chess_game_1_1main_menu.html#afc6b95850fc16e9ae0db67e2bb0111df',1,'ChessGame.mainMenu::components()']]]
];
