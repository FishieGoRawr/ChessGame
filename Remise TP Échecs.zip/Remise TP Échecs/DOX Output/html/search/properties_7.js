var searchData=
[
  ['this_5bint_20x_2c_20int_20y_5d_203',['this[int x, int y]',['../class_chess_game_1_1_board.html#ae21cbb3e01df01fbf7d141457b559690',1,'ChessGame::Board']]],
  ['turn_204',['Turn',['../class_chess_game_1_1_game.html#a0e21fa1d3f21a48875061a1a618fd576',1,'ChessGame::Game']]]
];
