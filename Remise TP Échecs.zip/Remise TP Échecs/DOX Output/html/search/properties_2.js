var searchData=
[
  ['losscount_198',['LossCount',['../class_chess_game_1_1_player.html#a05250471bc2fe92300c336b67d982ef4',1,'ChessGame::Player']]]
];
