var searchData=
[
  ['king_103',['King',['../class_chess_game_1_1_king.html',1,'ChessGame']]],
  ['knight_104',['Knight',['../class_chess_game_1_1_knight.html',1,'ChessGame']]]
];
