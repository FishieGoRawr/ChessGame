var searchData=
[
  ['currentpiece_196',['CurrentPiece',['../class_chess_game_1_1_tile.html#ac85c5b5140629c9f4628c112ccc67e20',1,'ChessGame::Tile']]]
];
