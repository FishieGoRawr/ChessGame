var searchData=
[
  ['name_200',['Name',['../class_chess_game_1_1_player.html#aad27c9e42b8c00f41a8135369e011258',1,'ChessGame::Player']]]
];
