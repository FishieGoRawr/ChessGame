var searchData=
[
  ['saveplayerlist_83',['savePlayerList',['../class_chess_game_1_1_chess_game.html#aed02e330cc523c8d736c66b4cc2c4614',1,'ChessGame.ChessGame.savePlayerList()'],['../class_chess_game_1_1_game.html#aa7bbf0eaef10167c66ddff6ddaee4aca',1,'ChessGame.Game.savePlayerList()']]],
  ['selectedtile_84',['SelectedTile',['../class_chess_game_1_1_board.html#ac731ceb726634377162480df8dcfe6f3',1,'ChessGame::Board']]],
  ['serializeplayerlist_85',['serializePlayerList',['../class_chess_game_1_1_chess_game.html#ac22b600f609226a6cc535d0db8f9825c',1,'ChessGame.ChessGame.serializePlayerList()'],['../class_chess_game_1_1_game.html#ad73ea078cbc2cbe4ea687b391f07d20d',1,'ChessGame.Game.serializePlayerList()']]],
  ['settings_86',['Settings',['../class_chess_game_1_1_properties_1_1_settings.html',1,'ChessGame::Properties']]],
  ['switchturns_87',['switchTurns',['../class_chess_game_1_1_game.html#a2a841fb7c547ac684e1e8dbfd8be348e',1,'ChessGame::Game']]]
];
