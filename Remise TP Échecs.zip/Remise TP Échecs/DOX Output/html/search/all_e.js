var searchData=
[
  ['queen_78',['Queen',['../class_chess_game_1_1_queen.html',1,'ChessGame.Queen'],['../class_chess_game_1_1_queen.html#a1c279e8dd0d21cedf5ef0e5019cdb9ee',1,'ChessGame.Queen.Queen()']]]
];
