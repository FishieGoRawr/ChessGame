var searchData=
[
  ['width_93',['Width',['../class_chess_game_1_1_board.html#a4b33578e697d2f2cef2d630ba7720a91',1,'ChessGame::Board']]],
  ['wincount_94',['WinCount',['../class_chess_game_1_1_player.html#a6f1bc6b404bd62abdb84eac73b3695ae',1,'ChessGame::Player']]]
];
